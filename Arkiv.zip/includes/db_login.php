<?php

$db_host = 'db4free.net';
$db_database = 'it_wars';
$db_username = 'rudi';
$db_password = 'rudi123';

?>