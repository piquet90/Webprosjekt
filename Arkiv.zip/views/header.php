<?php

echo <<<_END
<!DOCTYPE html>
<html>
<head>
<title>
Silicon Valley Startup
</title>
<link rel="stylesheet" type="text/css" href="$css">

<link href='http://fonts.googleapis.com/css?family=Glegoo' rel='stylesheet' type='text/css'>

<meta charset="UTF-8" />
</head>
<body>
<div id
_END;
?>