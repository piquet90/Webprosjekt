<?php

echo <<<_END
<div id="main" class="scroll">
<h3>Welcome</h3>
<p>Welcome to Silicon Valley Startup. We are currently working on
improving this website. More functions can come at any time.</p>
</div>

_END;



?>