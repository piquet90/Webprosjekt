<?php

echo <<<_END
</div> <!--end of wrapper-->
</body>
</html>
_END;
?>