<?php

$db_host = 'advm.no.mysql';
$db_database = 'advm_no';
$db_username = 'advm_no';
$db_password = 'database123';

?>